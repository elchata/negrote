package daos;

import beans.Precio;

public interface PrecioDAO extends BaseGenericDAOS<Precio>{

}
