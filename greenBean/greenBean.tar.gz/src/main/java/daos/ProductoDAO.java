package daos;

import beans.Producto;

public interface ProductoDAO extends BaseGenericDAOS<Producto>{

}
