package daos;

import beans.Categoria;

public interface CategoriaDAO extends BaseGenericDAOS<Categoria>{

}
