package daos;

import beans.Medida;

public interface MedidaDAO extends BaseGenericDAOS<Medida>{

}
