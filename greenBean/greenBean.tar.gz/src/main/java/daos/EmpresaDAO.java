package daos;
 
import beans.Empresa;

public interface EmpresaDAO extends BaseGenericDAOS<Empresa>{

}