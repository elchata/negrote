package daos;
 
import beans.Cliente;

public interface ClienteDAO extends BaseGenericDAOS<Cliente>{

}