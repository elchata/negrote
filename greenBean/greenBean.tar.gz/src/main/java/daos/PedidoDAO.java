package daos;

import beans.Pedido;

public interface PedidoDAO extends BaseGenericDAOS<Pedido>{

}
